package com.amdocs.dms.mode;

public class Doctor {
    private int doctorId;
    private String doctorName;
    private String mobileNumber;
    private String specialization;
    private String availableShift;
    private double fees;
    public Doctor()
    {
    	super();
    }
	public String getAvailableShift() 
	{
		// TODO Auto-generated method stub
		return null;
	}
	public String getSpecialization() 
	{
		// TODO Auto-generated method stub
		return null;
	}
	public String getMobileNumber() 
	{
		// TODO Auto-generated method stub
		return null;
	}
	public String getDoctorName() 
	{
		// TODO Auto-generated method stub
		return null;
	}
	public double getFees() 
	{
		// TODO Auto-generated method stub
		return 0;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public void setAvailableShift(String availableShift) 
	{
		this.availableShift = availableShift;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	

    // Constructors, getters, and setters
}
